import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class DisplayPLaneNormal {
	
	public static void main(String [ ]args) {
		
		HashMap<Integer, ArrayList<String>> Planes = new HashMap<>();
		Planes.put("1","A320","PLM_AIRBUS_IN_SERVICE","Passenger");
		
	}
		

}
