import java.util.Scanner;
public class DisplayPlane {
	
	public static void main(String []args) {
		String [] ACraft1= {"1","=", "A320","PLM_AIRBUS_IN_SERVICE","Passenger"};
		String [] ACraft2= {"2","=","A400M","PLM_AIRBUS_DEFINITION","cargo"};
		String [] ACraft3= {"3","=","A350","PLM_AIRBUS_FEASABILITY","Passenger"};
		String [] ACraft4= {"4","=","A380","PLM_AIRBUS_STOPPED","Passenger"};
		int NumberChoice;
		Scanner scan = new Scanner(System.in);
		System.out.println("Bienvenue dans l'application de gestion du cycle de vie d'avions Airbus");
		System.out.println("Faites votre choix dans le menu, saisissez le chiffre correspondant:");	
		
			
				while (scan.hasNextInt()) {
					NumberChoice = scan.nextInt();
						
					if (NumberChoice == 1) {
						System.out.println(displayAllCraft(ACraft1,ACraft2));
						//System.out.println(displayAllCraft(ACraft2));
						//System.out.println(displayAllCraft(ACraft3));
						//System.out.println(displayAllCraft(ACraft4));
						break;
					}
					if(NumberChoice==2) {
						System.out.println(displayProjectPlane(ACraft1));
					}
			}
			if (scan.hasNextInt()==false)		
			System.out.println("Mauvaise saisie! recommencez");
			
			}
			
			
			
	
	private static char[] displayAllCraft(String[] aCraft1, String[] aCraft2) {
		// TODO Auto-generated method stub
		return null;
	}




	public static String displayAllCraft(String [] tab) {
		int i;
		//String [] Plane=new String[7];
		String Plane="";
		for (i=0;i<tab.length;i++) {
			//Plane[i] = tab[i];
			Plane += " "+tab[i]+" ";
		}return Plane;
	}
	public static String displayProjectPlane(String  tab ) {
		System.out.println("Donnez un nom de projet d'avion");
		Scanner scan = new Scanner(System.in);
		String Projet = scan.next();
		String Plane="";
			for (int i=0;i<tab.length;i++) {
				Plane += tab[i];
				if (Plane.toLowerCase().contains(Projet.toLowerCase()))
					System.out.println(displayAllCraft(tab));
			}
				return Plane;
	}
			
				
}

