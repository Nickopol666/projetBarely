import java.util.Scanner;
public class PlaneAlternative {
	public static void main(String [] args) {
		String [][] Planes = {
							{"1","A320","Phase1","Util1"},
							{"2","A400","Phase2","Util2"},
							{"3","A380","Phase3","Util3"},
							{"4","A999","Phase4","Util4"}
							 };
		int MenuChoose;
		Scanner scan= new Scanner(System.in);
		System.out.println("Bienvenu blablabbla");
		System.out.println("Veuillez choisir un menu");
		
		MenuChoose = scan.nextInt();
		
		scan.close();
			if (MenuChoose==1) {
				System.out.println(displayPlaneAlt(Planes));
			}
		
	}
	public static String[] displayPlaneAlt(String [][]tab) {
		int i;
		int j;
		String []AltPlane = new String [tab.length];
		for(i=0;i<tab.length;i++) {			
			for(j=0;j<tab.length;j++) {				 
				AltPlane[j] += tab[i][j];		
			}
		}return AltPlane;
		
	}
}
